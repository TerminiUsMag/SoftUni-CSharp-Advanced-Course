﻿using System;

namespace Basketball
{
    public class StartUp
    {
        static void Main()
        {
        }
    }
}
