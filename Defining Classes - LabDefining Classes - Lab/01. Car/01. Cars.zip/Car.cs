﻿using System;

namespace CarManufacturer
{
    class Car
    {
        // TODO: define the Car class members here …
        int year;
        string make;
        string model;

        public int Year { get; set; }
        public string Model { get; set; }
        public string Make { get; set; }
    }
}

